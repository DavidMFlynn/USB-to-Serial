-------------------------------------------------------------------
   Release Notes for the MCP2200 Production Configuration Utility 
-------------------------------------------------------------------

		Microchip Technology, Inc.




-------------------------------------------------------------------
System Requirements
-------------------------------------------------------------------
Operating System: 	Windows XP SP3, Vista, and 7 (64 and 32 bit)
Other: 			    .NET2 Framework


-------------------------------------------------------------------
Versioning History
-------------------------------------------------------------------
Version 1.10:
 - Fixed reported errors

Version 1.00:
 - Initial release



-------------------------------------------------------------------
Contact Information
-------------------------------------------------------------------
Main Website: 		http://www.microchip.com
Technical Support: 	http://support.microchip.com
